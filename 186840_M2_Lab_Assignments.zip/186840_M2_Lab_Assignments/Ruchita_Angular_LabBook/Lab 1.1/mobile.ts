export class Mobile{
    mobileId:number;
    mobileName:string;
    mobileCost:number;
    constructor(id,name,cost){
        this.mobileId=id;
        this.mobileName=name;
        this.mobileCost=cost;
    }
    printMobileDetails()
    {   console.log("\n");
        console.log("Mobile ID: "+this.mobileId+ 
                    "\nMobile Name: "+this.mobileName+
                    "\nMobile Cost: "+this.mobileCost);
    }
}